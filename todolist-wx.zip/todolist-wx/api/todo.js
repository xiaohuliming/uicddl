import request from '@/utils/request.js'

//登录
export function loginAPI(data) {
	return request({
		url: '/auth/login',
		method: 'post',
		data
	})
}

//更新
export function updateAPI(data) {
	return request({
		url: '/todo/list/update',
		method: 'post',
		data
	})
}

//添加
export function addAPI(data) {
	return request({
		url: '/todo/list/add',
		method: 'post',
		data
	})
}

//删除
export function delAPI(data) {
	return request({
		url: '/todo/list/del',
		method: 'post',
		data
	})
}

//修改
export function alterAPI(data) {
	return request({
		url: '/todo/list/alter',
		method: 'post',
		data
	})
}

//查询
export function queryAPI(data) {
	return request({
		url: '/todo/list/query',
		method: 'post',
		data
	})
}

//根据item_id查询
export function queryByIdAPI(data) {
	return request({
		url: '/todo/list/query/item',
		method: 'post',
		data
	})
}

//获取openid
export function getOpenIdAPI(code) {
	return request({
		url: '/auth/open_id',
		method: 'post',
		data: {
			code
		}
	})
}