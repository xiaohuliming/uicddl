const env = 'dev'

const config = {
	dev: {
		sysTitle: 'TodoList小程序',
		baseAPI: "https://test.xxyyss.com",
	},
	prod: {
		sysTitle: 'TodoList小程序',
		baseAPI: "http://localhost:8600"
	}
}

export default config[env]