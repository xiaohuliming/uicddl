<script>
	import routingIntercept from '@/utils/permission.js'
	import {
		getToken
	} from '@/utils/auth.js'
	import {
		mapState,
		mapMutations
	} from 'vuex'
	// import {getUserInfoByTokenAPI} from '@/api/system.js'
	export default {
		methods: {
			// ...mapMutations(['setUser','setRole'])
		},
		computed: {
			// ...mapState(['user'])
		},
		onLaunch: async function() {
			console.log('App Launch')
			//1.对路由进行统一拦截，实现路由导航守卫 router.beforeEach 功能
			// routingIntercept()
			// //2.解决页面刷新vuex中的用户信息丢失问题,有token并且vuex中的用户信息为空 则重新获取用户信息
			// if (getToken()) {
			// 	if (Object.keys(this.user).length == 0) {
			// 		const res = await getUserInfoByTokenAPI()
			// 		this.setUser(res.data.user)
			// 		this.setRole(res.data.role)
			// 	}
			// }
		},

		onShow: async function() {
			console.log('App Show')


		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	/* 注意要写在第一行，同时给style标签加入lang="scss"属性 */
	@import "uview-v1_1.8.6/index.scss";
</style>