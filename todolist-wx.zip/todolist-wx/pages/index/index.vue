<template>
	<view class="page-container">
		<view class="text-center u-m-b-20">
			<u-icon name="man-add-fill" size="70"></u-icon>
			<view class="u-m-t-20 u-m-b-20 font-bold">{{getGreeting()}} {{username}}</view>
			<view>
				<u-tag class="mr-20" @click="refresh" text="重新获取" type="primary" size="mini" />
				<u-tag @click="logout" text="退出登录" type="error" size="mini" />
			</view>
		</view>
		<view class="section-title u-m-b-30">我的日程</view>
		<u-tabs :list="statusList" :is-scroll="true" :current="currTab" @change="tabChange"></u-tabs>
		<view class="todo-list">
			<u-swipe-action v-for="item in todoList" :key="item.item_id" @click="(index, index1) => todoActionClick(index, index1,item)" :options="options">
				<view class="todo-list-item">
					<view class="left">
						<view class="left-top">
							<view class="u-line-1" style="width: 50vw;">{{item.course_name}}</view>
							<view>
								<u-tag v-if="item.status == 0" text="未完成" type="warning" size="mini" />
								<u-tag v-else text="已完成" type="success" size="mini" />
							</view>
						</view>
						<view class="left-bottom">
							<view class="u-line-3 font-bold">{{item.note}}</view>
						</view>
					</view>
					<view class="right">
						<view class="right-top">
							<view class="text-gray">剩下的时间:</view>
							<view class="font-bold text-right">{{calculateRemainingTime(item.due_time)}}</view>
						</view>
						<view class="right-bottom">
							<view class="font-bold">{{formatISODate(item.due_time)}}</view>
							<view class="text-gray text-right">截止日期：</view>
						</view>
					</view>
				</view>
			</u-swipe-action>
			<u-empty v-if="todoList.length == 0"></u-empty>
		</view>

		<view @click="goAdd" class="add-btn">+</view>
		
	</view>
</template>

<script>
	import {formatISODate,calculateRemainingTime,getGreeting} from '@/utils/index.js'
	import {queryAPI,delAPI,alterAPI,updateAPI} from '@/api/todo.js'
	import {decrypt} from '@/utils/index.js'
	export default {
		data() {
			return {
				formatISODate,
				calculateRemainingTime,
				getGreeting,
				options: [{
						text: '完成',
						style: {
							backgroundColor: '#007aff'
						}
					},
					{
						text: '修改',
						style: {
							backgroundColor: '#23cfa8'
						}
					},
					{
						text: '删除',
						style: {
							backgroundColor: '#dd524d'
						}
					}
				],
				todoList: [],
				status: 0,
				statusList: [
					{name: '未完成',value: 0},
					{name: '已完成',value: 1},
					{name: '全部',value: 2},
				],
				currTab: 0,
				pageNum: 1,
				pageSize: 10,
				pageEnd: false,
				username: uni.getStorageSync("username") || '',
				token: uni.getStorageSync("token") || ''
			}
		},
		onShow() {
			if(this.token){
				this.onSearch()
			}else{
				uni.redirectTo({
					url: '/pages/login/login'
				})
			}
		},
		async onReachBottom() {
			if (!this.pageEnd) {
				this.pageNum++
				await this.getList()
			}
		},
		onLoad() {
			this.onSearch()
		},
		methods: {
			//类型tab改变
			async tabChange(index) {
				console.log(index);
				this.currTab = index;
				this.todoList = []
				const statusObj = this.statusList.find((f, i) => i == index)
				this.pageNum = 1
				this.status = statusObj.value
				await this.getList()
			},
			//输入框搜索
			onSearch() {
				this.pageNum = 1
				this.todoList = []
				this.getList()
			},
			async getList() {
				uni.showLoading()
				const res = await queryAPI({
					page: this.pageNum,
					size: this.pageSize,
					username: this.username,
					token: this.token,
					status: this.status
				})
				uni.hideLoading()
				//若没有数据则到底了
				this.pageEnd = res.data.list.length == 0
				//有数据且数组中没有才追加
				res.data.list.forEach(m => {
					if (this.todoList.every(s => s.item_id != m.item_id)) {
						this.todoList.push({...m})
					}
				})
			},
			todoActionClick(index, index1,item) {
				console.log("todoActionClick:", index1,item)
				if(index1 == 0){//完成
					let _this = this
					uni.showModal({
						title: '提示',
						content: '确定完成吗',
						success: async function(res) {
							if (res.confirm) {
								const res = await alterAPI({
									item_id: item.item_id,
									token: _this.token,
									username: _this.username,
									status: 1 //0 未完成 1 已完成
								})
								uni.showToast({
									icon: 'success',
									title: res.message
								})
								setTimeout(() => {
									_this.onSearch()
								},1000)
							}
						}
					});
					
				}
				if(index1 == 1){//修改
					uni.navigateTo({
						url: '/pages/editTodo/editTodo?item_id='+item.item_id
					})
					return
				}
				if(index1 == 2){//删除
					let _this = this
					uni.showModal({
						title: '提示',
						content: '确定删除吗',
						success: async function(res) {
							if (res.confirm) {
								const res = await delAPI({
									item_id: item.item_id,
									token: _this.token,
									username: _this.username
								})
								uni.showToast({
									icon: 'success',
									title: res.message
								})
								setTimeout(() => {
									_this.onSearch()
								},1000)
							}
						}
					});
					
				}
			},
			goAdd() {
				uni.navigateTo({
					url: '/pages/editTodo/editTodo'
				})
			},
			logout() {
				let _this = this
				uni.showModal({
					title: '提示',
					content: '确定退出吗',
					success: function(res) {
						if (res.confirm) {
							uni.removeStorageSync("token")
							uni.removeStorageSync("username")
							uni.removeStorageSync("password")
							uni.redirectTo({
								url: '/pages/login/login'
							})
						}
					}
				});
			},
			refresh(){
				let _this = this
				uni.showModal({
					title: '提示',
					content: '确定重新从网站获取数据吗',
					success: async function(res) {
						if (res.confirm) {
							const res = await updateAPI({
								username: _this.username,
								password: decrypt(uni.getStorageSync("password")),
								token: _this.token,
							})
							if(res.code == 200){
								uni.showToast({
									icon: 'success',
									title: res.message
								})
								setTimeout(() => {
									_this.onSearch()
								},1000)
							}
						}
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.page-container {
		padding: 20rpx;
		box-sizing: border-box;

		.section-title {
			text-align: center;
			padding: 40rpx 0;
			background-color: #2c2c2c;
			border-radius: 30rpx;
			color: #fff;
		}

		.todo-list {
			padding-top: 40rpx;
			.todo-list-item {
				height: 260rpx;
				border-radius: 30rpx;
				padding: 16rpx;
				background: #f6f6f6;
				display: flex;
				margin-bottom: 40rpx;
				.left,
				.right {
					flex: 1;
					display: flex;
					flex-direction: column;
				}

				.right {
					align-items: flex-end;
				}

				.left-top,
				.right-top,
				.left-bottom,
				.right-bottom {
					flex: 1;
					display: flex;
					flex-direction: column;
					justify-content: center;
				}
				
				.left-bottom{
					font-size: 13px;
				}

				.left-top {
					font-size: 30rpx;
					font-weight: bold;
				}
			}
		}

		.add-btn {
			width: 100rpx;
			height: 100rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			background: #2c2c2c;
			border-radius: 50%;
			color: #fff;
			font-size: 40rpx;
			font-weight: bold;
			position: fixed;
			bottom: 40rpx;
			left: 50%;
			transform: translateX(-50%);
			box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.3);
		}
	}
</style>