<template>
	<view class="page-container">
		<u-section title="编辑事项" :right="false" class="u-m-b-20"></u-section>
		<u-form :model="form" ref="uForm" label-position="top">
			<u-form-item label="事项名">
				<u-input v-model="form.note" type="textarea" placeholder="请输入事项名" />
			</u-form-item>
			<u-form-item label="课程名">
				<u-input v-model="form.course_name" type="textarea" placeholder="请输入事项名" />
			</u-form-item>
			<u-form-item label="截止日期">
				<u-input v-model="dateRange" @click="dateRangeShow = true" type="select" placeholder="请选择截止日期" />
				<u-picker v-model="dateRangeShow" @confirm="dateRangeChange" mode="time" :params="params"></u-picker>
			</u-form-item>
<!-- 			<u-form-item label="备注">
				<u-input v-model="form.note" type="textarea" placeholder="请输入备注" />
			</u-form-item> -->
			<u-button @click="handleSave" type="primary">提交</u-button>
		</u-form>
	</view>
</template>

<script>
	import {addAPI,alterAPI,queryByIdAPI} from '@/api/todo.js'
	import {formatISODate} from '@/utils/index.js'
	export default {
		data() {
			return {
				form: {
					item_id: null,
					item_name: '',
					course_name: '',
					due_time: '',
					note: '',
					status: 0
				},
				dateRangeShow: false,
				params: {
					year: true,
					month: true,
					day: true,
					hour: true,
					minute: true,
					second: true
				},
				username: uni.getStorageSync("username") || '',
				token: uni.getStorageSync("token") || '',
				dateRange: '',
			};
		},
		async onLoad(opt) {
			console.log(opt);
			if(!this.token){
				uni.redirectTo({
					url: '/pages/login/login'
				})
			}else if(opt.item_id){//修改需要回显数据
				const res = await queryByIdAPI({
					username: this.username,
					token: this.token,
					item_id: parseInt(opt.item_id)
				})
				console.log(res);
				this.form = res.data.list[0]
				this.form.due_time = formatISODate(res.data.list[0].due_time)
				this.dateRange = this.form.due_time
			}
		},
		methods: {
			dateRangeChange(e) {
				console.log(e);
				this.dateRange = e.year + '-' + e.month + "-" + e.day + " " + e.hour + ":" + e.minute + ":" + e.second
			},
			async handleSave(){
				uni.showLoading()
				let api = this.form.item_id ? alterAPI : addAPI
				const res = await api({
					...this.form,
					username: this.username,
					token: this.token,
					status: 0,
					due_time: this.dateRange
				})
				uni.hideLoading()
				uni.showToast({
					icon: 'success',
					title: res.message
				})
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/index/index'
					})
				},1000)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.page-container {
		padding: 20rpx;
		box-sizing: border-box;
	}
</style>