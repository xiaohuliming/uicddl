<template>
	<view class="container">
		<view class="login-title">
			{{sysTitle}}
		</view>
		<u-form :model="form" ref="uForm">
			<u-form-item label="账号">
				<u-input v-model="form.username" placeholder="请输入账号" />
			</u-form-item>
			<u-form-item label="密码">
				<u-input v-model="form.password" type="password" placeholder="请输入密码" />
			</u-form-item>
			<view class="mb-10"><u-button @click="login" type="primary"><u-icon name="account-fill"
						class="mr-10"></u-icon>登录</u-button></view>

			<u-button @click="handleWxLogin" type="success"><u-icon name="weixin-fill"
					class="mr-10"></u-icon>微信登录</u-button>
			<view class="text-red">提示：首次使用微信登录需要先输入账号和密码</view>
		</u-form>
	</view>
</template>

<script>
	import config from '@/config.js'
	import {encrypt} from '@/utils/index.js'
	import {
		loginAPI,
		getOpenIdAPI
	} from '@/api/todo.js'
	export default {
		data() {
			return {
				form: {
					username: '',
					password: '',
					open_id: ''
				},
				sysTitle: config.sysTitle
			};
		},
		methods: {
			//账号密码登录
			async login() {
				uni.showLoading()
				const res = await loginAPI(this.form)
				uni.hideLoading()
				uni.showToast({
					icon: 'success',
					title: res.message
				})
				uni.setStorageSync("token", res.token)
				uni.setStorageSync("username", res.username)
				uni.setStorageSync("password", encrypt(res.password))
				setTimeout(() => {
					uni.redirectTo({
						url: '/pages/index/index'
					})
				}, 1000)
			},
			//微信登录
			handleWxLogin() {
				let _this = this
				uni.showLoading()
				wx.login({
					async success(res) {
						if (res.code) {
							// console.log('获取code成功！' + res.code)
							const resp = await getOpenIdAPI(res.code)
							uni.hideLoading()
							// console.log('获取openid成功！' + resp)
							_this.form.open_id = resp.data.openid
							await _this.login()

						} else {
							uni.hideLoading()
							console.log('获取code失败！' + res.errMsg)
						}
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: 60rpx;
		box-sizing: border-box;

		.login-title {
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			font-size: 40rpx;
			font-weight: bold;
		}
	}
</style>