
import config from '@/config.js'

export default function(options) {
	return new Promise((resolve, reject) => {
		uni.request({
			method: options.method || 'GET',
			data: options.data || options.params || {}, //参照axios的api写法 post请求为data，get请求为params
			url: config.baseAPI + options.url,
			// header: {
			//Authorization: "Bearer "+getToken()
			// 	Authorization: getToken()
			// },
			success: (res) => {
				// console.log("request success", res.data);
				uni.hideLoading()
				if(res.data.code == 200){
					resolve(res.data)
				}else if (res.data.code == 401) { //token失效
				    
					uni.showToast({
						icon: 'error',
						title: '登录失效,请重新登录'
					})
					setTimeout(() => {
						uni.removeStorageSync("token")
						uni.removeStorageSync("username")
						uni.redirectTo({
							url: '/pages/login/login'
						})
					},1000)
				}else if (res.data.code == 402) {
					uni.showToast({
						icon: 'error',
						title: '请绑定账号'
					})
					setTimeout(() => {
						uni.removeStorageSync("token")
						uni.removeStorageSync("username")
						uni.redirectTo({
							url: '/pages/login/login'
						})
					},1000)
				}else{
					uni.showToast({
						icon: 'error',
						title: res.data.message || '请求接口异常'
					})
				}
			},
			fail: (err) => {
				uni.hideLoading()
				uni.showToast({
					title: '请求接口失败'
				})
				reject(err)
			}
		})
	})
}