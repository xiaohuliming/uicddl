// 封装成一个函数，用于格式化ISO 8601格式的日期时间字符串
export function formatISODate(isoDateString) {
    // 解析ISO 8601格式的日期时间字符串
    let date = new Date(isoDateString);

    // 格式化日期时间
    let year = date.getFullYear();
    let month = String(date.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需要加1
    let day = String(date.getDate()).padStart(2, '0');
    let hours = String(date.getHours()).padStart(2, '0');
    let minutes = String(date.getMinutes()).padStart(2, '0');
    let seconds = String(date.getSeconds()).padStart(2, '0');

    // 拼接成最终的日期时间字符串
    // let formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    let formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}`;

    return formattedDateString;
}

// 封装成一个函数，用于计算当前时间与ISO 8601格式的日期时间字符串之间的剩余时间
export function calculateRemainingTime(isoDateString) {
    // 解析ISO 8601格式的日期时间字符串
    let targetDate = new Date(isoDateString);
    let currentDate = new Date();

    // 计算剩余时间（毫秒）
    let remainingTime = targetDate - currentDate;

    // 如果剩余时间小于等于0，说明目标时间已经过去
    if (remainingTime <= 0) {
        return "目标时间已过";
    }

    // 将剩余时间转换为年、月、日、时
    let seconds = Math.floor(remainingTime / 1000);
    let minutes = Math.floor(seconds / 60);
    let hours = Math.floor(minutes / 60);
    let days = Math.floor(hours / 24);
    let years = Math.floor(days / 365);
    days = days % 365;
    let months = Math.floor(days / 30);
    days = days % 30;

    // 计算剩余的小时
    hours = hours % 24;

    // 拼接成最终的剩余时间字符串（去掉分，并且如果年、月、日、时都等于0，则不显示这些部分）
    let remainingTimeString = "";
    if (years > 0) remainingTimeString += `${years}年 `;
    if (months > 0) remainingTimeString += `${months}月 `;
    if (days > 0) remainingTimeString += `${days}日 `;
    if (hours > 0) remainingTimeString += `${hours}时`;

    // 如果所有部分都为0，则显示 "0时"
    if (remainingTimeString === "") {
        remainingTimeString = "0时";
    }

    return remainingTimeString.trim();
}

//获取问候语
export function getGreeting() {
    const now = new Date();
    const hour = now.getHours();

    if (hour >= 5 && hour < 12) {
        return "早上好！";
    } else if (hour >= 12 && hour < 18) {
        return "中午好！";
    } else if (hour >= 18 && hour < 22) {
        return "晚上好！";
    } else {
        return "夜深了，早点休息！";
    }
}


const key = uni.getStorageSync("token") //秘钥

/**
 * 异或加密/解密函数
 * @param {string} text - 需要加密或解密的字符串
 * @param {string} key - 用于加密或解密的密钥
 * @returns {string} - 加密或解密后的字符串
 */
function xorEncryptDecrypt(text) { 
    let output = '';
    let keyLength = key.length;
    for (let i = 0; i < text.length; i++) {
        output += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % keyLength));
    }
    return output;
}

// 异或加密函数
export function encrypt(str) {
    return xorEncryptDecrypt(str);
}

// 异或解密函数
export function decrypt(encryptedStr) {
   return xorEncryptDecrypt(encryptedStr);
}