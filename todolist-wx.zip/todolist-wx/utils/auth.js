const authorizationKey = 'uni-token'

export function getToken() {
	return uni.getStorageSync(authorizationKey)
}

export function setToken(authorization) {
	uni.setStorageSync(authorizationKey, authorization)
}

export function removeToken(authorization) {
	return uni.removeStorageSync(authorizationKey)
}