module.exports = {
	devServer: {
		port: 9090 // 修改为你想要的端口号
	}
};