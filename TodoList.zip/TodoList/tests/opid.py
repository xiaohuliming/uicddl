import requests
from urllib3 import request

from conf.app import APP_ID, APP_SECRET

data = {
    'appid': APP_ID,
    'secret': APP_SECRET,
    'js_code': '0a3X540w3Slas33gRx0w3ggg2d1X5404',
    'grant_type': 'authorization_code',
}

url = 'https://api.weixin.qq.com/sns/jscode2session'

print(requests.get(url, data).json())