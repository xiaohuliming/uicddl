import requests

headers = {
    'cookie': 'sessionid=N5KSFln38JSfnv5t3xznJNQviYnq5ERB;username=t330025032;token=N5KSFln38JSfnv5t3xznJNQviYnq5ERB'
}


def test_add():
    data = {
        "item_name": 'test',
        "course_name": '计算机应用',
        "due_time": '',
        "note": '',
        "status": 0,
        'token': 'sZQEEWoNNFPJld6eS9evsKILZamtqJMg',
        'username': 't330025032'
    }
    print(requests.post('https://test.xxyyss.com/todo/list/add', headers=headers, json=data).text)


def test_del():
    data = {
        "item_id": 6,
        'token': 'sZQEEWoNNFPJld6eS9evsKILZamtqJMg',
        'username': 't330025032'
    }
    print(requests.post('http://127.0.0.1:8000/todo/list/del', headers=headers, json=data).text)


def test_alter():
    data = {
        'item_id': 6,
        'item_name': 'testc',
        'course_name': 'kc',
        'due_time': '2024-01-01 12:12:12',
        'note': 'ces',
        'status': 1,
    }
    print(requests.post('http://127.0.0.1:8000/todo/list/alter', headers=headers, json=data).text)


def test_query():
    data = {
        "page": 1,
        "size": 100,
        'status':1,
        "token":"mqJ1B2wLcv0ZxR3kDO9sV8OiJlnprEXk",
        "username":"t330025032"
    }
    print(requests.post('https://test.xxyyss.com/todo/list/query', headers=headers, json=data).text)

def test_update():
    print(requests.post('http://127.0.0.1:8000/todo/list/update', headers=headers).text)


def login():
    data = {
        'username': 't330025032',
        'password': 'Hzj050916',
        # 'open_id':'okF4e54yIYoJWZBFqacnnPzNkRwY'
    }
    print(requests.post('https://test.xxyyss.com/auth/login', data=data,headers=headers).text)
def test_item():
    data = {
        'item_id': 1,
        "token": "sZQEEWoNNFPJld6eS9evsKILZamtqJMg",
        "username": "t330025032"
    }
    print(requests.post('https://test.xxyyss.com/todo/list/query/item', headers=headers, json=data).text)

def test_status():
    data = {
        'status': 1,
        "token": "7rfR9F5vRIHeuDAmbH7N3jvj3yLdKj5B",
        "username": "t330025032"
    }
    print(requests.post('https://test.xxyyss.com/todo/list/query/status', headers=headers, json=data).text)
if __name__ == '__main__':
    # test_add()
    # test_del()
    # test_alter()
    # test_query()
    # test_update()
    login()
    # test_query()
    # test_item()
    # test_status()
