from django.urls import path

from apps.todo import views

urlpatterns = [
    path('update', views.TodoListUpdate.as_view()),
    path('add', views.TodoAdd.as_view()),
    path('del', views.TodoDel.as_view()),
    path('alter', views.TodoAlter.as_view()),
    path('query', views.TodoListQuery.as_view()),
    path('query/item', views.TodoQuery.as_view()),
    path('query/status', views.TodoStatusQuery.as_view()),
]
