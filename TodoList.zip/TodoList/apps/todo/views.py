import re

import requests
from bs4 import BeautifulSoup
from django.http import JsonResponse
from django.utils import timezone
from rest_framework.views import APIView

from apps.authentication.models import User
from apps.todo.models import TodoItem
from utils.func import timestamp_to_time_str


class Crawler:
    def __init__(self, username, password):
        # 模拟浏览器请求头
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
        }
        self.username = username
        self.password = password
        self.flag, self.cookie = self.get_login_cookie(self.username, self.password)

    # 获取登录后的cookie值
    def get_login_cookie(self, su, sp):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
        }
        session = requests.Session()
        session.headers = self.headers
        resp = session.get("https://ispace.uic.edu.cn/login/index.php")
        html = BeautifulSoup(resp.text, "lxml")
        login_token = html.find("input", attrs={"name": "logintoken"}).get("value")

        data = {
            "logintoken": login_token,
            "username": su,
            "password": sp
        }
        resp = session.post(
            "https://ispace.uic.edu.cn/login/index.php",
            data=data,
        )

        session.get("https://ispace.uic.edu.cn/login/index.php?testsession=13040")

        cookie = {}
        for key, value in session.cookies.items():
            cookie[key] = value
        flag = False
        if '<title>Dashboard</title>' in session.get('https://ispace.uic.edu.cn/my/').text:
            flag = True
        return flag, cookie

    # 获取课程ddl
    def run(self):
        # 获取key
        url = "https://ispace.uic.edu.cn/my/"
        resp = requests.get(url, headers=self.headers, cookies=self.cookie)
        key = re.search('"sesskey":"(?P<key>.*?)",', resp.text).group("key")

        # 准备发送请求
        url = f"https://ispace.uic.edu.cn/lib/ajax/service.php?sesskey={key}&info=core_calendar_get_action_events_by_timesort"
        data = "[{\"index\":0,\"methodname\":\"core_calendar_get_action_events_by_timesort\",\"args\":{\"limitnum\":6,\"timesortfrom\":1720713600,\"limittononsuspendedevents\":true}}]"

        # 发送请求
        resp = requests.post(
            url=url,
            data=data,
            headers=self.headers,
            cookies=self.cookie
        )

        # 遍历循环每个ddl
        ret_dic_ls = []
        for json_data in resp.json():
            json_data = json_data["data"]["events"]
            for event in json_data:
                name = event["activityname"]
                time_str = re.search('time=(?P<time>.*?)"', event["formattedtime"]).group("time")
                time_str = timestamp_to_time_str(int(time_str))
                class_name = event["course"]["fullname"]
                if {
                    "course_name": name,
                    "due_time": time_str,
                    "note": class_name
                } not in ret_dic_ls:
                    pass
                    # print({
                    #     "course_name": name,
                    #     "due_time": time_str,
                    #     "note": class_name
                    # })
                    ret_dic_ls.append(
                        {
                            "course_name": name,
                            "due_time": time_str,
                            "note": class_name
                        }
                    )

        # 循环翻页
        next_id = resp.json()[0]["data"]["lastid"]
        limit_count = 11
        while True:
            data = (
                "[{\"index\":0,\"methodname\":\"core_calendar_get_action_events_by_timesort\",\"args\":{\"aftereventid\":"
                f"{next_id - 1}"
                ",\"limitnum\":"
                f"{limit_count}"
                ",\"timesortfrom\":1720713600,\"limittononsuspendedevents\":true}}]")
            try:
                resp = requests.post(
                    url=url,
                    data=data,
                    headers=self.headers,
                    cookies=self.cookie
                )
                next_id = resp.json()[0]["data"]["lastid"]
            except:
                break
            for json_data in resp.json():
                json_data = json_data["data"]["events"]
                for event in json_data:
                    name = event["activityname"]
                    time_str = re.search('time=(?P<time>.*?)"', event["formattedtime"]).group("time")
                    time_str = timestamp_to_time_str(int(time_str))
                    class_name = event["course"]["fullname"]
                    if {
                        "course_name": name,
                        "due_time": time_str,
                        "note": class_name
                    } not in ret_dic_ls:
                        # print({
                        #     "course_name": name,
                        #     "due_time": time_str,
                        #     "note": class_name
                        # })
                        pass
                        ret_dic_ls.append(
                            {
                                "course_name": name,
                                "due_time": time_str,
                                "note": class_name
                            }
                        )
            limit_count += 5
        for item in ret_dic_ls:
            if TodoItem.objects.filter(course_name=item['course_name'], due_time=item['due_time'], note=item['note']).first():
                continue
            todo = TodoItem(item_user=self.username, item_name='导入', course_name=item['course_name'], due_time=item['due_time'], note=item['note'], status=0)
            todo.save()


class TodoListUpdate(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                username = request.data.get('username')
                password = request.data.get('password')
                crawler = Crawler(username, password)
                if crawler.cookie:
                    crawler.run()
                self.response_data['status'] = True
                self.response_data['code'] = 200
                self.response_data['message'] = '更新成功！'
                return JsonResponse(self.response_data)
            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})

        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})


class TodoAdd(APIView):
    """
    手动添加 todo 项目
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                item_name = request.data.get('item_name')
                course_name = request.data.get('course_name')
                due_time = request.data.get('due_time')
                note = request.data.get('note')
                status = request.data.get('status', 0)
                if item_name is None or course_name is None or due_time is None or note is None or status is None:
                    self.response_data['status'] = False
                    self.response_data['code'] = 500
                    self.response_data['message'] = '添加失败！字段不存在！'
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
                else:
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = '添加成功！'
                    self.response_data['response_data'] = {
                        "item_name": item_name,
                        "course_name": course_name,
                        "due_time": due_time,
                        "note": note,
                        "status": status,
                    }
                    todo = TodoItem(item_user=request.data.get('username'), item_name=item_name, course_name=course_name, due_time=due_time, note=note, status=status)
                    todo.save()

                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})
        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})


class TodoDel(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                item_id = request.data.get('item_id')
                todo = TodoItem.objects.filter(id=item_id).first()
                if todo:
                    todo.status = 3
                    todo.save()
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = '删除成功！'
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
                else:
                    self.response_data['status'] = False
                    self.response_data['code'] = 500
                    self.response_data['message'] = 'id不存在！'
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})
        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})


class TodoAlter(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                item_id = request.data.get('item_id')
                item_name = request.data.get('item_name')
                course_name = request.data.get('course_name')
                due_time = request.data.get('due_time')
                note = request.data.get('note')
                status = request.data.get('status')
                todo = TodoItem.objects.filter(id=item_id).first()
                if todo:
                    if item_name:
                        todo.item_name = item_name
                    if course_name:
                        todo.course_name = course_name
                    if due_time:
                        todo.due_time = due_time
                    if note:
                        todo.note = note
                    if status:
                        todo.status = status
                    todo.save()
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = '修改成功！'
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
                else:
                    self.response_data['status'] = False
                    self.response_data['code'] = 500
                    self.response_data['message'] = 'id不存在！'
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})
        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})


class TodoListQuery(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                page = request.data.get('page')
                size = request.data.get('size')
                status = request.data.get('status')
                if status == 0 or status == 1 or status == 3:
                    todos = TodoItem.objects.filter(item_user=request.data.get('username'), status=status).all().order_by('id')
                else:
                    todos = TodoItem.objects.filter(item_user=request.data.get('username')).all().order_by('id')
                if page == 0:
                    items = todos[:page * size]
                else:
                    items = todos[(page - 1) * size:page * size]
                items = [{
                    'item_id': item.id,
                    'item_name': item.item_name,
                    'course_name': item.course_name,
                    'due_time': item.due_time,
                    'note': item.note,
                    'status': item.status
                } for item in items if status != 3]
                if items:
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = "查询成功！"
                    self.response_data['data'] = {}
                    self.response_data['data']['count'] = len(items)
                    self.response_data['data']['list'] = items
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
                else:
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = "查询成功！"
                    self.response_data['data'] = {}
                    self.response_data['data']['count'] = 0
                    self.response_data['data']['list'] = []
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})
        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})


class TodoQuery(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                item_id = request.data.get('item_id')
                print(item_id)
                todos = TodoItem.objects.filter(id=item_id).first()
                if todos:
                    items = [{
                        'item_id': todos.id,
                        'item_name': todos.item_name,
                        'course_name': todos.course_name,
                        'due_time': todos.due_time,
                        'note': todos.note,
                        'status': todos.status
                    }]
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = "查询成功！"
                    self.response_data['data'] = {}
                    self.response_data['data']['count'] = len(items)
                    self.response_data['data']['list'] = items
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
                else:
                    self.response_data['status'] = False
                    self.response_data['code'] = 200
                    self.response_data['message'] = "查询失败！item_id不存在"
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})

            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})

        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})


class TodoStatusQuery(APIView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.response_data = {}

    def post(self, request):
        user = User.objects.filter(username=request.data.get('username')).first()
        print(user.token)
        print(request.data.get("token"))
        if user.token == request.data.get("token"):
            now_with_tz = timezone.localtime(timezone.now(), timezone=user.expire_date.tzinfo)
            if user.expire_date > now_with_tz:
                status = request.data.get('status')
                username = request.data.get('username')
                if status != 2:
                    todos = TodoItem.objects.filter(item_user=username, status=status).all()
                else:
                    todos = TodoItem.objects.filter(item_user=username).all()
                print(todos)
                if todos:

                    items = [{
                        'item_id': item.id,
                        'item_name': item.item_name,
                        'course_name': item.course_name,
                        'due_time': item.due_time,
                        'note': item.note,
                        'status': item.status
                    } for item in todos]

                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = "查询成功！"
                    self.response_data['data'] = {}
                    self.response_data['data']['count'] = len(items)
                    self.response_data['data']['list'] = items
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
                else:
                    self.response_data['status'] = True
                    self.response_data['code'] = 200
                    self.response_data['message'] = "查询成功！"
                    self.response_data['data'] = {}
                    self.response_data['data']['count'] = 0
                    self.response_data['data']['list'] = []
                    return JsonResponse(self.response_data, safe=False, json_dumps_params={'ensure_ascii': False})
            else:
                return JsonResponse({'status': False, 'code': 401, 'message': '登陆过期！'}, safe=False, json_dumps_params={'ensure_ascii': False})

        else:
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})
