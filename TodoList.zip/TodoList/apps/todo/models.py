from django.db import models

# 事项名称 课程名称 截至时间 备注 状态
class TodoItem(models.Model):
    # 所属用户
    item_user = models.CharField(max_length=200,default='')
    # 事项名称
    item_name = models.CharField(max_length=200)
    # 课程名称
    course_name = models.CharField(max_length=200, null=True, blank=True)
    # 截至时间
    due_time = models.DateTimeField()
    # 备注
    note = models.TextField(null=True, blank=True)
    # 状态，假设可以用数字表示不同状态，比如 0 表示未完成，1 表示已完成
    status = models.IntegerField(default=0)

    class Meta:
        db_table = 'todo_list'