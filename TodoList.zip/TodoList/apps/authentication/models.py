from django.db import models


class Token(models.Model):
    username = models.CharField(max_length=100)
    token = models.CharField(max_length=100)
    expire_date = models.DateTimeField()

    class Meta:
        db_table = 'token'


class User(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    open_id = models.CharField(max_length=100)
    token = models.CharField(max_length=100)
    expire_date = models.DateTimeField()

    class Meta:
        db_table = 'user'
