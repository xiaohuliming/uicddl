import datetime

import requests
from django.http import JsonResponse
from rest_framework.views import APIView

from apps.authentication.models import User
from apps.todo.views import Crawler
from conf.app import APP_ID, APP_SECRET
from utils.func import generate_custom_token


class LoginView(APIView):

    def post(self, request):
        # 账号
        username = request.data.get('username')
        # 密码
        password = request.data.get('password')
        # open id
        open_id = request.data.get('open_id')
        # 生成 token
        token = generate_custom_token()
        # 当 open id 为空时，不允许登陆
        if open_id == "":
            user = User.objects.filter(username=username, password=password).first()
            if user:
                # 刷新 token 时间
                user.token = token
                # 保存
                user.save()
                # 返回响应结果
                return JsonResponse({'status': True, 'code': 200, 'message': '登陆成功！', 'token': token, 'username': user.username, 'password': user.password}, safe=False, json_dumps_params={'ensure_ascii': False})
            return JsonResponse({'status': True, 'code': 402, 'message': '登陆失败！账号密码错误！open id不能为空'}, safe=False, json_dumps_params={'ensure_ascii': False})
        # 判断 open id 是否绑定账号
        user = User.objects.filter(open_id=open_id).first()

        # open id 有绑定账号时
        if user:
            # 刷新 token 时间
            user.token = token
            # 保存
            user.save()

            # 返回响应结果
            return JsonResponse({'status': True, 'code': 200, 'message': '登陆成功！', 'token': token, 'username': user.username, 'password': user.password}, safe=False, json_dumps_params={'ensure_ascii': False})
        # open id 没有绑定账号时
        else:
            # 创建爬虫对象
            crawler = Crawler(username, password)
            # 判断账号能否登陆
            if crawler.flag:
                # 创建系统账号
                User.objects.create(username=username, password=password, open_id=open_id, token=token, expire_date=datetime.datetime.now() + datetime.timedelta(days=14)).save()
                # 运行爬虫
                crawler.run()
                return JsonResponse({'status': True, 'code': 200, 'message': '登陆成功！', 'token': token, 'username': username, 'password': password}, safe=False, json_dumps_params={'ensure_ascii': False})
            # 账号不能登陆官网时触发
            else:
                return JsonResponse({'status': True, 'code': 402, 'message': '登陆失败！请检查账号密码'}, safe=False, json_dumps_params={'ensure_ascii': False})


class GetOpenId(APIView):
    def post(self, request, *args, **kwargs):
        code = request.data.get('code')
        data = {
            'appid': APP_ID,
            'secret': APP_SECRET,
            'js_code': code,
            'grant_type': 'authorization_code',
        }

        url = 'https://api.weixin.qq.com/sns/jscode2session'

        response = requests.get(url, data)
        if response.status_code == 200:
            return JsonResponse({'status': True, 'code': 200, 'message': '获取成功！', 'data': response.json()}, safe=False, json_dumps_params={'ensure_ascii': False})
        else:
            return JsonResponse({'status': False, 'code': 500, 'message': '获取失败！'}, safe=False, json_dumps_params={'ensure_ascii': False})
