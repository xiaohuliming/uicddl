import random
import string
import time
from datetime import datetime

from django.utils import timezone


def generate_custom_token(length=32):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))


# 时间戳转化为字符串
def timestamp_to_time_str(timestamp):
    time_array = time.localtime(timestamp)
    # 假设已有一个不带时区信息的时间字符串
    original_time_str = time.strftime("%Y-%m-%d %H:%M:%S", time_array)
    original_time = datetime.strptime(original_time_str, '%Y-%m-%d %H:%M:%S')

    # 将其转换为本地时区的时间
    local_time = timezone.make_aware(original_time, timezone.get_current_timezone())
    return local_time
