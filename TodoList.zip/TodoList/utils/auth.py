from django.http import JsonResponse

from apps.authentication.models import Token


def is_authenticated(view_func):
    def wrapper(request, *args, **kwargs):
        if Token.objects.filter(username=request.data.get('username')).first().token == request.data.get("token"):
            # token 存在，认为用户已登录，可以执行被装饰的视图函数
            return view_func(request, *args, **kwargs)
        else:
            # token 不存在，用户未登录，返回未授权响应或重定向到登录页面
            return JsonResponse({'status': False, 'code': 402, 'message': '没有权限请求！请先登陆！'}, safe=False, json_dumps_params={'ensure_ascii': False})

    return wrapper
