import re

import requests
from bs4 import BeautifulSoup

from apps.todo.models import TodoItem
from utils.func import timestamp_to_time_str
