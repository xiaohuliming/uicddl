# TodoList Api 文档

## 简介

本 API 文档为项目中提供的各种接口提供详细说明。

## API 基础信息

Host：为服务器域名或IP，本地使用 `http://localhost:<port>` 或 `http://127.0.0.1:<port>`

认证方式为：Token 认证，Token 获取方式为 login 接口

请求方式：`POST` 此项目所有请求均使 `POST` 方式

code代码说明：

- 200：请求成功
- 500：请求失败
- 401：鉴权有误

## 接口列表

### Login

请求地址：`/auth/login`

接口描述：使用指定网站账号，登陆网站成功后，创建账号，返回 Token 参数

请求参数：

| 参数       | 类型     | 是否必填 | 描述 |
|----------|--------|------|----|
| username | string | 是    | 账号 |
| password | string | 是    | 密码 |

返回示例：

```json
{
  "status": true,
  "code": 200,
  "message": "登陆成功！",
  "username": "t330025032",
  "token": "nQZpgeqSD8R2oGzQxvNmTRRk2cCaLzp5"
}
```

### Update

请求地址：`/todo/list/update`

接口描述：从网站获取数据到本地数据库

请求头：请构造以下请求头一起请求此接口

请求参数：

| 参数       | 类型     | 是否必填 | 描述 |
|----------|--------|------|----|
| token    | string | 是    | 鉴权 |
| username | string | 是    | 账号 |
| password | string | 是    | 密码 |

响应示例：

```json
{
  "status": true,
  "code": 200,
  "message": "更新成功！"
}
```

### Add

请求地址：`/todo/list/add`

接口描述：手动添加数据行

请求参数：

| 参数          | 类型     | 是否必填 | 描述                 |
|-------------|--------|------|--------------------|
| token       | string | 是    | 鉴权                 |
| username    | string | 是    | 账号                 |
| item_name   | string | 是    | 名称                 |
| course_name | string | 是    | 课程名称               |
| due_time    | string | 是    | 到期时间               |
| note        | string | 是    | 描述 备注              |
| status      | int    | 否    | 状态：0 未完成 1 已完成 默认0 |

响应示例：

```json
{
  "status": true,
  "code": 200,
  "message": "添加成功！",
  "response_data": {
    "item_name": "test",
    "course_name": "计算机应用",
    "due_time": "2024-02-01 23:21:21",
    "note": "测试",
    "status": 0
  }
}
```

### Del

请求地址：`/todo/list/del`

接口描述：删除数据行

请求参数：

| 参数       | 类型     | 是否必填 | 描述 |
|----------|--------|------|----|
| token    | string | 是    | 鉴权 |
| username | string | 是    | 账号 |
| item_id  | int    | 是    | 索引 |

响应示例：

```json
{
  "status": true,
  "code": 200,
  "message": "删除成功！"
}
```

### Alter

请求地址：`/todo/list/alter`

接口描述：修改行数据

请求参数：

| 参数          | 类型     | 是否必填 | 描述                 |
|-------------|--------|------|--------------------|
| token       | string | 是    | 鉴权                 |
| username    | string | 是    | 账号                 |
| item_id     | int    | 是    | 需要修改的索引            |
| item_name   | string | 否    | 名称                 |
| course_name | string | 否    | 课程名称               |
| due_time    | string | 否    | 到期时间               |
| note        | string | 否    | 描述 备注              |
| status      | int    | 否    | 状态：0 未完成 1 已完成 默认0 |

响应示例：

```json
{
  "status": true,
  "code": 200,
  "message": "修改成功！"
}
```


### Query

请求地址：`/todo/list/query`

接口描述：从网站获取数据到本地数据库

请求参数：

| 参数       | 类型     | 是否必填 | 描述   |
|----------|--------|----|------|
| token    | string | 是  | 鉴权   |
| username | string | 是  | 账号   |
| page     | int    | 是  | 页码   |
| size     | int    | 是  | 一页数量 |
| status   | int    |    | 一页数量 |

响应示例：

```json
{
  "status": true,
  "code": 200,
  "message": "查询成功！",
  "data": {
    "count": 13,
    "list": [
      {
        "item_id": 1,
        "item_name": "导入",
        "course_name": "EEP Student Feedback 2024",
        "due_time": "2024-09-06T15:59:00Z",
        "note": "Student English Learning Hub",
        "status": 0
      },
      {
        "item_id": 2,
        "item_name": "导入",
        "course_name": "Submit \" Word_to_PPT.pptx\" here(optional task)",
        "due_time": "2024-09-09T07:00:00Z",
        "note": "IT Course 2024 Fall",
        "status": 0
      },
      {
        "item_id": 3,
        "item_name": "导入",
        "course_name": "Submit \"Word is Wonderful.docx\" here",
        "due_time": "2024-09-09T07:00:00Z",
        "note": "IT Course 2024 Fall",
        "status": 0
      },
      {
        "item_id": 4,
        "item_name": "导入",
        "course_name": "Submit \"UIC Introduction.pptx\" here",
        "due_time": "2024-09-09T07:00:00Z",
        "note": "IT Course 2024 Fall",
        "status": 0
      },
      {
        "item_id": 5,
        "item_name": "导入",
        "course_name": "Group tutorial 1",
        "due_time": "2024-09-21T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 7,
        "item_name": "导入",
        "course_name": "Lecture Quiz 1",
        "due_time": "2024-09-27T00:00:00Z",
        "note": "Foundations of C Programming",
        "status": 0
      },
      {
        "item_id": 8,
        "item_name": "导入",
        "course_name": "Group tutorial 2",
        "due_time": "2024-09-29T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 9,
        "item_name": "导入",
        "course_name": "Group tutorial 3",
        "due_time": "2024-10-12T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 10,
        "item_name": "导入",
        "course_name": "Group tutorial 4",
        "due_time": "2024-10-19T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 11,
        "item_name": "导入",
        "course_name": "Data analysis",
        "due_time": "2024-11-09T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 12,
        "item_name": "导入",
        "course_name": "Group PPT",
        "due_time": "2024-12-07T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 13,
        "item_name": "导入",
        "course_name": "Term paper",
        "due_time": "2024-12-29T16:00:00Z",
        "note": "English Through Media (1001) (Dr. Xiaoping WU) [Semester 1 of 2024-2025]",
        "status": 0
      },
      {
        "item_id": 14,
        "item_name": "test",
        "course_name": "计算机",
        "due_time": "2024-02-01T15:21:21Z",
        "note": "测试",
        "status": 0
      }
    ]
  }
}

```