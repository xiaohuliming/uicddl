# 部署文档

## 服务器部署

TodoList 项目使用 Docker 部署，也可以使用其他方式部署，以下是以Docker方式部署的文档

MySQL数据库创建

```bash
CREATE DATABASE `todo_list` CHARACTER SET 'utf8mb4';
```

> 注意：一定要使用 Linux 服务器环境部署，Windows 下多多少少存在少许问题

1. 项目上传到 Linux 服务器
2. 执行打包命令：`docker build -t TodoList:0.0.1 .`
3. 运行打包镜像：`docker run -d --name TodoList -p 8000:8000 TodoList:0.0.1`

8000为django项目端口

## 本地测试

迁移数据库

`python manage.py migrate`

运行

`python mange.py runserver 0.0.0.0:8002`